<?php
namespace Packt\Chp8\DSL\AST;

interface Variable extends Expression
{

}