<?php
namespace Packt\Chp8\DSL\Exception;

use Exception;

class ParsingException extends Exception
{

}