<?php
namespace Packt\Chp8\DSL\Exception;

use Exception;

class UnknownVariableException extends Exception
{

}