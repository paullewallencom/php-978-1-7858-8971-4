This class convert doc, docx to txt.
It reads the content of doc, docx file and return the content in soimple txt format to search.