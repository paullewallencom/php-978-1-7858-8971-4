<?php
if(!empty($_POST)) {
  $title = $_POST['title'];
  $content = $_POST['content'];
  $tags = $_POST['tags'];
  
}
?>
