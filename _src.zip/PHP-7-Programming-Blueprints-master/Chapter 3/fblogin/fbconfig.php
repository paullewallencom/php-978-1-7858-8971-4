
//Facebook App Details (jsust define them)

define('FB_APP_ID', 'YOUR APP ID'); 
define('FB_APP_SECRET', 'YOUR APP SECRET');
define('FB_REDIRECT_URI', 'http://localhost/user_login/');

