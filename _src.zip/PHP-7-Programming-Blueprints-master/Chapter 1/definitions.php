define('NO_RESULTS_MESSAGE', 'No results found');

