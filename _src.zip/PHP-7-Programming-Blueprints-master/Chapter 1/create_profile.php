<html>
<body>
<form action="post_profile.php" method="POST">

  <label>Name</label><input name="name">
  <label>Age</label><input name="age">
  <label>Country</label><input name="country">

</form>
</body>
</html>