INSERT INTO user_profiles ('Chin Wu', 30, 'Mongolia');
INSERT INTO user_profiles ('Erik Schmidt', 22, 'Germany');
INSERT INTO user_profiles ('Rashma Naru', 33, 'India');
