<?php 

$name = $_POST['name'] ?? "";

$age = $_POST['country'] ?? "";

$country = $_POST['country'] ?? "";

$input_values =  [
 'name' => $name,
 'age' => $age,
 'country' => $country
];
?>