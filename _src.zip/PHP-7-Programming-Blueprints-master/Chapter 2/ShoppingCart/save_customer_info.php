<!doctype html>
<html>
<head>
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
<style> 
th, td {
    padding: 15px;
    text-align: left;
}
th, td {
    border-bottom: 1px solid #ddd;
}
</style>
</head>

<body>
<form method="post">
<table>
<tr><td>Name</td><td><input type="text" name="fullname"></td></tr>
<tr><td>Address</td><td><input type="text" name="address"></td></tr>
<tr><td>Email</td><td><input type="text" name="email"></td></tr>
<tr><td>Credit Card</td><td><input type="text" name="credit_card"></td></tr>
<tr><td colspan="2"><input type="submit" name="submit" value="Purchase"></td></tr>
</table>
</form>
</html>
